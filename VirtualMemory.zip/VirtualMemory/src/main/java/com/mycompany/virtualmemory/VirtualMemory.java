/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.virtualmemory;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

/*
 * Main class to run the simulation
 * Virtual Memory System Simulation
 * This program simulates a virtual memory system with a producer-consumer model.
 * It includes a shared memory buffer, page replacement policies (FIFO and LRU),
 */

public class VirtualMemory {
    public static void main(String[] args) {
        try {
            
            SharedMemory sharedMemory = new SharedMemory();
            
            SemaphoreManager semManager = new SemaphoreManager();
            
            PageReplacementPolicy policy = new LRUPageReplacement(); 
            
            BackingStore backingStore = new BackingStore("swap.dat");
            
            MemoryManager memoryManager = new MemoryManager(sharedMemory, backingStore, policy);
            
            Logger logger = new Logger("memory_log.txt");
            
            DisplayManager display = new DisplayManager(sharedMemory);
            
            Thread displayThread = new Thread(display);
            displayThread.start();
            
            int numProducers = 3;
            int numConsumers = 2;
            
            Producer[] producers = new Producer[numProducers];
            Consumer[] consumers = new Consumer[numConsumers];
            
            for (int i = 0; i < numProducers; i++) {
                producers[i] = new Producer(i, sharedMemory, semManager, memoryManager, logger);
                Thread producerThread = new Thread(producers[i]);
                producerThread.start();
            }
            
            for (int i = 0; i < numConsumers; i++) {
                consumers[i] = new Consumer(i, sharedMemory, semManager, memoryManager, logger);
                Thread consumerThread = new Thread(consumers[i]);
                consumerThread.start();
            }
            
            System.out.println("Press Enter to terminate the simulation...");
            System.in.read();
            
            display.stop();
            backingStore.close();
            logger.close();
            System.exit(0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


/*
 * SharedMemory class simulates a shared memory buffer and page table.
 * It includes methods for inserting and removing items from the buffer,
 * managing the page table, and handling page faults.
 */
class SharedMemory {
    public static final int BUFFER_SIZE = 5;
    public static final int PAGE_SIZE = 4; 
    public static final int MAX_PAGES = 10; 
    
    private int[] buffer;
    private int in, out;
    private int count;
    private int[] pageTable;
    private int[] frameTable;
    private int pageFaults;
    private long[] lastAccessed; 
    
    public SharedMemory() {
        buffer = new int[BUFFER_SIZE];
        in = 0;
        out = 0;
        count = 0;
        pageTable = new int[MAX_PAGES];
        frameTable = new int[MAX_PAGES];
        pageFaults = 0;
        lastAccessed = new long[MAX_PAGES];
        
        for (int i = 0; i < MAX_PAGES; i++) {
            pageTable[i] = -1;
            frameTable[i] = -1;
        }
    }
    
    public void insertItem(int item) {
        buffer[in] = item;
        in = (in + 1) % BUFFER_SIZE;
        count++;
    }
    
    public int removeItem() {
        int item = buffer[out];
        out = (out + 1) % BUFFER_SIZE;
        count--;
        return item;
    }
    
    public int getPageTableEntry(int pageNum) {
        return pageTable[pageNum];
    }
    
    public void setPageTableEntry(int pageNum, int frameNum) {
        pageTable[pageNum] = frameNum;
        updateAccessTime(pageNum);
    }
    
    public int getFrameTableEntry(int frameNum) {
        return frameTable[frameNum];
    }
    
    public void setFrameTableEntry(int frameNum, int pageNum) {
        frameTable[frameNum] = pageNum;
    }
    
    public void incrementPageFaults() {
        pageFaults++;
    }
    
    public int getPageFaults() {
        return pageFaults;
    }
    
    public void updateAccessTime(int pageNum) {
        lastAccessed[pageNum] = System.currentTimeMillis();
    }
    
    public long getLastAccessTime(int pageNum) {
        return lastAccessed[pageNum];
    }
    
    public int getBufferCount() {
        return count;
    }
    
    public int[] getBufferContents() {
        return buffer.clone();
    }
    
    public int getIn() {
        return in;
    }
    
    public int getOut() {
        return out;
    }
    
    public int[] getPageTable() {
        return pageTable.clone();
    }
    
    public int[] getFrameTable() {
        return frameTable.clone();
    }
}

/*
 * SemaphoreManager class manages semaphores for synchronization
 * between producer and consumer threads.
 */
class SemaphoreManager {
    private Semaphore mutex;
    private Semaphore empty;
    private Semaphore full;
    
    public SemaphoreManager() {
        mutex = new Semaphore(1);       
        empty = new Semaphore(SharedMemory.BUFFER_SIZE); 
        full = new Semaphore(0);       
    }
    
    public void acquireMutex() throws InterruptedException {
        mutex.acquire();
    }
    
    public void releaseMutex() {
        mutex.release();
    }
    
    public void acquireEmpty() throws InterruptedException {
        empty.acquire();
    }
    
    public void releaseEmpty() {
        empty.release();
    }
    
    public void acquireFull() throws InterruptedException {
        full.acquire();
    }
    
    public void releaseFull() {
        full.release();
    }
}


/*
 * Semaphore class implements a simple semaphore mechanism
 * for thread synchronization.
 */
class Semaphore {
    private int value;
    
    public Semaphore(int initialValue) {
        value = initialValue;
    }
    
    public synchronized void acquire() throws InterruptedException {
        while (value <= 0) {
            wait();
        }
        value--;
    }
    
    public synchronized void release() {
        value++;
        notify();
    }
    
    public synchronized int getValue() {
        return value;
    }
}

/*
 * PageReplacementPolicy interface defines the contract for page replacement policies.
 * It includes methods for selecting a victim page and getting the policy name.
 */
interface PageReplacementPolicy {
    int selectVictimPage(SharedMemory memory);
    String getPolicyName();
}

/*
 * FIFOPageReplacement class implements the FIFO page replacement policy.
 * It selects the oldest page in memory for replacement.
 */
class FIFOPageReplacement implements PageReplacementPolicy {
    private int nextVictim = 0;
    
    @Override
    public int selectVictimPage(SharedMemory memory) {
      
        int victim = nextVictim;
        nextVictim = (nextVictim + 1) % SharedMemory.MAX_PAGES;
        return victim;
    }
    
    @Override
    public String getPolicyName() {
        return "FIFO";
    }
}

/*
 * LRUPageReplacement class implements the LRU page replacement policy.
 * It selects the least recently used page in memory for replacement.
 */
class LRUPageReplacement implements PageReplacementPolicy {
    @Override
    public int selectVictimPage(SharedMemory memory) {
        int[] frameTable = memory.getFrameTable();
        long oldestTime = Long.MAX_VALUE;
        int victimFrame = 0;
        
        for (int i = 0; i < SharedMemory.MAX_PAGES; i++) {
            int pageInFrame = frameTable[i];
            if (pageInFrame != -1) {
                long accessTime = memory.getLastAccessTime(pageInFrame);
                if (accessTime < oldestTime) {
                    oldestTime = accessTime;
                    victimFrame = i;
                }
            }
        }
        
        return victimFrame;
    }
    
    @Override
    public String getPolicyName() {
        return "LRU";
    }
}

/*
 * BackingStore class simulates a backing store for virtual memory.
 * It handles reading and writing pages to a file.
 */

class BackingStore {
    private RandomAccessFile file;
    
    public BackingStore(String filename) throws IOException {
        file = new RandomAccessFile(filename, "rw");
        
        for (int i = 0; i < SharedMemory.MAX_PAGES; i++) {
            byte[] emptyPage = new byte[SharedMemory.PAGE_SIZE * Integer.BYTES];
            file.write(emptyPage);
        }
    }
    
    public void writePage(int pageNum, int[] pageData) throws IOException {
        file.seek(pageNum * SharedMemory.PAGE_SIZE * Integer.BYTES);
        for (int i = 0; i < SharedMemory.PAGE_SIZE; i++) {
            file.writeInt(pageData[i]);
        }
    }
    
    public int[] readPage(int pageNum) throws IOException {
        int[] pageData = new int[SharedMemory.PAGE_SIZE];
        file.seek(pageNum * SharedMemory.PAGE_SIZE * Integer.BYTES);
        for (int i = 0; i < SharedMemory.PAGE_SIZE; i++) {
            pageData[i] = file.readInt();
        }
        return pageData;
    }
    
    public void close() throws IOException {
        file.close();
    }
}

/*
 * MemoryManager class manages the memory operations,
 * including page fault handling and memory access.
 */
class MemoryManager {
    private SharedMemory memory;
    private BackingStore backingStore;
    private PageReplacementPolicy replacementPolicy;
    
    public MemoryManager(SharedMemory memory, BackingStore backingStore, PageReplacementPolicy policy) {
        this.memory = memory;
        this.backingStore = backingStore;
        this.replacementPolicy = policy;
    }
    
    public boolean isPageInMemory(int pageNum) {
        return memory.getPageTableEntry(pageNum) != -1;
    }
    
    public void handlePageFault(int pageNum) throws IOException {
        memory.incrementPageFaults();
        
        int frameNum = findFreeFrame();
        if (frameNum == -1) {
            
            frameNum = replacementPolicy.selectVictimPage(memory);
            int victimPage = memory.getFrameTableEntry(frameNum);
            
            if (victimPage != -1) {
                int[] pageData = readFromPhysicalMemory(frameNum);
                backingStore.writePage(victimPage, pageData);
                memory.setPageTableEntry(victimPage, -1);
            }
        }
        
        int[] pageData = backingStore.readPage(pageNum);
        writeToPhysicalMemory(frameNum, pageData);
        
        memory.setPageTableEntry(pageNum, frameNum);
        memory.setFrameTableEntry(frameNum, pageNum);
    }
    
    private int findFreeFrame() {
        int[] frameTable = memory.getFrameTable();
        for (int i = 0; i < SharedMemory.MAX_PAGES; i++) {
            if (frameTable[i] == -1) {
                return i;
            }
        }
        return -1; 
    }
    
    private int[] readFromPhysicalMemory(int frameNum) {
        
        int[] pageData = new int[SharedMemory.PAGE_SIZE];
        for (int i = 0; i < SharedMemory.PAGE_SIZE; i++) {
            pageData[i] = 0; 
        }
        return pageData;
    }
    
    private void writeToPhysicalMemory(int frameNum, int[] pageData) {

    }
    
    public PageReplacementPolicy getReplacementPolicy() {
        return replacementPolicy;
    }
}

/*
 * Producer class simulates a producer thread that generates items
 * and inserts them into the shared memory buffer.
 * It handles page faults and synchronization with the consumer thread.
 */
class Producer implements Runnable {
    private int id;
    private SharedMemory memory;
    private SemaphoreManager semManager;
    private MemoryManager memoryManager;
    private Logger logger;
    private Random random;
    private boolean running;
    
    public Producer(int id, SharedMemory memory, SemaphoreManager semManager, 
                   MemoryManager memoryManager, Logger logger) {
        this.id = id;
        this.memory = memory;
        this.semManager = semManager;
        this.memoryManager = memoryManager;
        this.logger = logger;
        this.random = new Random();
        this.running = true;
    }
    
    @Override
    public void run() {
        try {
            while (running) {
                
                int item = random.nextInt(100);
                
                int virtualAddress = memory.getIn();
                int pageNum = virtualAddress / SharedMemory.PAGE_SIZE;
                
                if (!memoryManager.isPageInMemory(pageNum)) {
                    logger.log("Producer " + id + ": Page fault occurred for page " + pageNum);
                    memoryManager.handlePageFault(pageNum);
                } else {
                    memory.updateAccessTime(pageNum);
                }
                
                semManager.acquireEmpty();
                semManager.acquireMutex();
                
                memory.insertItem(item);
                logger.log("Producer " + id + ": Produced item " + item + " at position " + virtualAddress + 
                          " (Page " + pageNum + ")");
                
                semManager.releaseMutex();
                semManager.releaseFull();
                
                Thread.sleep(random.nextInt(500) + 500);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void stop() {
        running = false;
    }
}

/*
 * Consumer class simulates a consumer thread that removes items
 * from the shared memory buffer.
 * It handles page faults and synchronization with the producer thread.
 */
class Consumer implements Runnable {
    private int id;
    private SharedMemory memory;
    private SemaphoreManager semManager;
    private MemoryManager memoryManager;
    private Logger logger;
    private Random random;
    private boolean running;
    
    public Consumer(int id, SharedMemory memory, SemaphoreManager semManager, 
                   MemoryManager memoryManager, Logger logger) {
        this.id = id;
        this.memory = memory;
        this.semManager = semManager;
        this.memoryManager = memoryManager;
        this.logger = logger;
        this.random = new Random();
        this.running = true;
    }
    
    @Override
    public void run() {
        try {
            while (running) {
                int virtualAddress = memory.getOut();
                int pageNum = virtualAddress / SharedMemory.PAGE_SIZE;
                
                if (!memoryManager.isPageInMemory(pageNum)) {
                    logger.log("Consumer " + id + ": Page fault occurred for page " + pageNum);
                    memoryManager.handlePageFault(pageNum);
                } else {
                    memory.updateAccessTime(pageNum);
                }
                
                semManager.acquireFull();
                semManager.acquireMutex();
                
                int item = memory.removeItem();
                logger.log("Consumer " + id + ": Consumed item " + item + " from position " + virtualAddress + 
                          " (Page " + pageNum + ")");
                
                semManager.releaseMutex();
                semManager.releaseEmpty();
                
                Thread.sleep(random.nextInt(1000) + 500);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void stop() {
        running = false;
    }
}

/*
 * Logger class handles logging messages to a file and optionally to the console.
 * It includes methods for logging messages and setting console output.
 */
class Logger {
    private PrintWriter writer;
    private boolean consoleOutput;
    
    public Logger(String filename) throws IOException {
        this.writer = new PrintWriter(new FileWriter(filename));
        this.consoleOutput = true;
    }
    
    public synchronized void log(String message) {
        String timestamp = new SimpleDateFormat("HH:mm:ss.SSS").format(new Date());
        String logMessage = timestamp + " - " + message;
        writer.println(logMessage);
        writer.flush();
        
        if (consoleOutput) {
            System.out.println(logMessage);
        }
    }
    
    public void setConsoleOutput(boolean enable) {
        this.consoleOutput = enable;
    }
    
    public void close() {
        writer.close();
    }
}

/*
 * DisplayManager class handles the display of the virtual memory system status.
 * It includes methods for updating the display and clearing the console.
 */
class DisplayManager implements Runnable {
    private SharedMemory memory;
    private boolean running;
    
    public DisplayManager(SharedMemory memory) {
        this.memory = memory;
        this.running = true;
    }
    
    @Override
    public void run() {
        try {
            while (running) {
                displayMemoryStatus();
                Thread.sleep(1000); 
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    private void displayMemoryStatus() {
        clearConsole();
        System.out.println("======== VIRTUAL MEMORY SYSTEM STATUS ========");
        System.out.println("Buffer Status:");
        System.out.println("  Items in buffer: " + memory.getBufferCount() + "/" + SharedMemory.BUFFER_SIZE);
        
        int[] buffer = memory.getBufferContents();
        System.out.print("  Buffer Content: [ ");
        for (int i = 0; i < SharedMemory.BUFFER_SIZE; i++) {
            if (i >= memory.getOut() && i < memory.getOut() + memory.getBufferCount()) {
                System.out.print(buffer[i % SharedMemory.BUFFER_SIZE] + " ");
            } else {
                System.out.print("_ ");
            }
        }
        System.out.println("]");
        
        System.out.println("\nPage Table:");
        int[] pageTable = memory.getPageTable();
        for (int i = 0; i < SharedMemory.MAX_PAGES; i++) {
            System.out.println("  Page " + i + " -> Frame " + 
                               (pageTable[i] == -1 ? "Not in memory" : pageTable[i]));
        }
        
        System.out.println("\nFrame Table:");
        int[] frameTable = memory.getFrameTable();
        for (int i = 0; i < SharedMemory.MAX_PAGES; i++) {
            System.out.println("  Frame " + i + " -> Page " + 
                               (frameTable[i] == -1 ? "Empty" : frameTable[i]));
        }
        
        System.out.println("\nMemory Statistics:");
        System.out.println("  Page Faults: " + memory.getPageFaults());
        System.out.println("===========================================");
    }
    
    private void clearConsole() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
           
            for (int i = 0; i < 50; i++) {
                System.out.println();
            }
        }
    }
    
    public void stop() {
        running = false;
    }
}
